"""Fixed seeded generation and logprob comparison across server variants."""
import argparse
import asyncio
import json
from pathlib import Path

import aiohttp
from sla_client import URL, requests

ROOT = Path(__file__).parent


async def main(label):
    results = []
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=600)) as session:
        for mode, params in [
            ("greedy", {"temperature": 0}),
            ("random", {"temperature": 0.8, "top_p": 1.0}),
            ("filtered", {"temperature": 0.8, "top_p": 0.9, "top_k": 40}),
        ]:
            for req in requests()[:8]:
                body = dict(model="qwen-sampler", prompt=req["prompt"], max_tokens=64,
                            seed=42 + req["id"], ignore_eos=True, logprobs=5,
                            return_token_ids=True, **params)
                async with session.post(URL + "/v1/completions", json=body) as r:
                    r.raise_for_status()
                    item = await r.json()
                choice = item["choices"][0]
                assert len(choice["token_ids"]) == 64, choice
                results.append(dict(mode=mode, id=req["id"], token_ids=choice["token_ids"],
                                    logprobs=choice["logprobs"], usage=item["usage"]))
    (ROOT / f"artifacts/{label}-eval.json").write_text(json.dumps(results))
    print(f"EVAL_COMPLETE: {label}: {len(results)} requests", flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--label", required=True)
    asyncio.run(main(p.parse_args().label))
