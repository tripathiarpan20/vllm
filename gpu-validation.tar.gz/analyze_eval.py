"""Compare complete generated token sequences and returned log probabilities."""
import json
from pathlib import Path

ROOT = Path(__file__).parent
art = ROOT / "artifacts"
reference = json.loads((art / "baseline-a-eval.json").read_text())
results = []
for label in ("baseline-b", "patched-a", "patched-b"):
    actual = json.loads((art / f"{label}-eval.json").read_text())
    assert len(reference) == len(actual) == 24
    for mode in ("greedy", "random", "filtered"):
        paired = [(a, b) for a, b in zip(reference, actual) if a["mode"] == mode]
        assert all((a["mode"],a["id"]) == (b["mode"],b["id"]) for a,b in paired)
        results.append(dict(label=label, mode=mode, requests=len(paired),
                            identical_tokens=sum(a["token_ids"] == b["token_ids"] for a,b in paired),
                            identical_logprobs=sum(a["logprobs"] == b["logprobs"] for a,b in paired)))
(art / "eval-summary.json").write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
