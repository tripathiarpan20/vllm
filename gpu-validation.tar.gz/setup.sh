#!/bin/bash
set -euo pipefail
cd /workspace/pareton-sampler-review/runtime-src
export SETUPTOOLS_SCM_PRETEND_VERSION=0.3.1.dev6
export VLLM_USE_PRECOMPILED=1
export VLLM_PRECOMPILED_WHEEL_LOCATION=https://wheels.vllm.ai/e6b1a5e5e3fce6b777c5f63398f87c7c911a40b3/vllm-0.3.1.dev6%2Bge6b1a5e5e-cp38-abi3-manylinux_2_28_x86_64.whl
export UV_HTTP_TIMEOUT=300
/root/.local/bin/uv pip install --python ../.venv/bin/python --constraint ../constraints.txt -e . --torch-backend=auto
/root/.local/bin/uv pip install --python ../.venv/bin/python --constraint ../constraints.txt pytest pytest-asyncio tblib aiohttp numpy

# Align JIT compiler and CRT with the torch CUDA 13.2 runtime headers.
/root/.local/bin/uv pip install --python ../.venv/bin/python --constraint ../constraints.txt "nvidia-cuda-nvcc==13.2.*" "nvidia-cuda-crt==13.2.*" "nvidia-nvvm==13.2.*"

cd ..
mkdir -p cuda-link-libs
ln -sf "$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13" cuda-link-libs/libcudart.so
ln -sf "$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13/lib/libnvrtc.so.13" cuda-link-libs/libnvrtc.so
