"""Record public runtime provenance and verify the pinned model weights."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess

from huggingface_hub import HfApi
import torch
import triton
import vllm

ROOT = Path(__file__).parent
REV = "017b9c7af6b5689d5dd426a76e0bc077eb5ca20a"
info = HfApi().model_info("Qwen/Qwen3.8-27B-FP8", revision=REV, files_metadata=True)
assert info.sha == REV
checks = []
for item in info.siblings:
    if not item.rfilename.endswith(".safetensors"):
        continue
    path = ROOT / "model" / item.rfilename
    with path.open("rb") as f:
        digest = hashlib.file_digest(f, "sha256").hexdigest()
    assert digest == item.lfs.sha256, item.rfilename
    checks.append(dict(file=item.rfilename, size=path.stat().st_size, sha256=digest))
(ROOT / "artifacts/model-manifest.json").write_text(json.dumps(dict(model=info.id, revision=REV, weights=checks), indent=2))
env = dict(python=platform.python_version(), torch=torch.__version__, cuda=torch.version.cuda,
           triton=triton.__version__, vllm=vllm.__version__, vllm_path=vllm.__file__,
           gpu=torch.cuda.get_device_name(), runtime_source="e6b1a5e5e3fce6b777c5f63398f87c7c911a40b3",
           implementation_base="8538017f4b1d01b543345f5dbe1993cb66c80fa9")
(ROOT / "artifacts/environment.json").write_text(json.dumps(env, indent=2))
for filename, command in [
    ("nvidia-smi.txt", ["nvidia-smi"]),
    ("pip-freeze.txt", ["/root/.local/bin/uv", "pip", "freeze", "--python", str(ROOT / ".venv/bin/python")]),
    ("lscpu.txt", ["lscpu"]),
]:
    (ROOT / "artifacts" / filename).write_text(subprocess.check_output(command, text=True))
print(json.dumps(env), flush=True)
print(f"MODEL_VERIFIED: {len(checks)} shards", flush=True)
