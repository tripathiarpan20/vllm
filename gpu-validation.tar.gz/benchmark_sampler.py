"""Paired sampler and final-reduction measurements; no model throughput claims."""
import importlib.util
import json
from pathlib import Path
import statistics
import torch
from vllm.triton_utils import triton
from vllm.v1.worker.gpu.sample import gumbel as patched

root = Path(__file__).parent
spec = importlib.util.spec_from_file_location('baseline_gumbel', root / 'baseline_gumbel.py')
baseline = importlib.util.module_from_spec(spec)
spec.loader.exec_module(baseline)
torch.manual_seed(42)

def measure(fn, graph=False):
    for _ in range(15): fn()
    torch.cuda.synchronize()
    if graph:
        g = torch.cuda.CUDAGraph()
        with torch.cuda.graph(g):
            for _ in range(50): fn()
        fn = g.replay
        count = 1
        divisor = 50
    else:
        count, divisor = 50, 1
    times=[]
    for _ in range(25):
        start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(count):fn()
        end.record();end.synchronize()
        times.append(start.elapsed_time(end)*1000/(count*divisor))
    return {'median_us':statistics.median(times),'min_us':min(times),'max_us':max(times)}

out = root / 'artifacts/kernel-bench.jsonl'
with out.open('w') as f:
    for fp64 in (False,True):
        for vocab in (32768,128256,248320):
            for rows in (1,4,8,16,32,128,512):
                logits=torch.randn(rows,vocab,device='cuda',dtype=torch.float32)
                mapping=torch.arange(rows,device='cuda',dtype=torch.int32)
                temp=torch.ones(rows,device='cuda')
                seeds=torch.arange(rows,device='cuda',dtype=torch.int64)
                pos=seeds+7
                kwargs=dict(apply_temperature=True,is_drafting=True,use_fp64=fp64)
                old=lambda:baseline.gumbel_sample(logits,mapping,temp,seeds,pos,**kwargs)
                new=lambda:patched.gumbel_sample(logits,mapping,temp,seeds,pos,**kwargs)
                assert torch.equal(old(),new())
                n=triton.cdiv(vocab,1024)
                values=torch.randn(rows,n,device='cuda',dtype=torch.float64 if fp64 else torch.float32)
                ids=torch.randint(vocab,(rows,n),device='cuda',dtype=torch.int64)
                sampled=torch.empty(rows,device='cuda',dtype=torch.int64)
                def old_reduce(): return ids.gather(1,values.argmax(-1,keepdim=True)).view(-1)
                def new_reduce():
                    patched._gumbel_sample_reduce_kernel[(rows,)](values,ids,sampled,n,BLOCK_SIZE=triton.next_power_of_2(n))
                    return sampled
                assert torch.equal(old_reduce(),new_reduce())
                for stage,a,b in [('full',old,new),('reduce',old_reduce,new_reduce)]:
                    for graph in (False,True):
                        pair=[]
                        # Alternate measurement order within each cell.
                        for first in (False,True):
                            result={}
                            for name,fn in ([('old',a),('new',b)] if not first else [('new',b),('old',a)]):
                                result[name]=measure(fn,graph)
                            pair.append(result)
                        r=dict(stage=stage,graph=graph,rows=rows,vocab=vocab,fp64=fp64,pairs=pair)
                        f.write(json.dumps(r)+'\n');f.flush()
                        print(json.dumps(r),flush=True)
