"""Real GDN kernels, baseline vs patched _forward_core, using real metadata."""
import ast
import json
import sys
import types
from pathlib import Path
from unittest.mock import patch

import torch

sys.path.insert(0, str(Path(__file__).parent / 'test-checkout'))
from tests.v1.attention.utils import BatchSpec, create_common_attn_metadata, create_vllm_config
from vllm.config import SpeculativeConfig, set_current_vllm_config
from vllm.model_executor.layers.mamba.gdn import qwen_gdn_linear_attn as gdn
from vllm.model_executor.layers.mamba.mamba_utils import MambaStateShapeCalculator
from vllm.v1.attention.backends.gdn_attn import GDNAttentionMetadataBuilder
from vllm.v1.kv_cache_interface import MambaSpec

ROOT = Path(__file__).parent
H, HV, K, V, WIDTH = 16, 32, 128, 128, 4
KD, VD = H*K, HV*V
PREFIX = 'model.layers.0.linear_attn'

def load_forward(path):
    cls = next(n for n in ast.parse(path.read_text()).body if isinstance(n, ast.ClassDef) and n.name == 'QwenGatedDeltaNetAttention')
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == '_forward_core')
    scope = dict(vars(gdn))
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(path), 'exec'), scope)
    return scope['_forward_core'], scope

@torch.inference_mode()
def main():
    torch.manual_seed(42)
    cfg = create_vllm_config(model_name=str(ROOT/'model'), max_model_len=4096, max_num_seqs=32)
    cfg.additional_config = {'gdn_prefill_backend': 'triton'}
    cfg.speculative_config = SpeculativeConfig(method='ngram', num_speculative_tokens=3)
    cfg.cache_config.mamba_cache_mode = 'none'
    conv_shape, ssm_shape = MambaStateShapeCalculator.gated_delta_net_state_shape(1,H,HV,K,V,WIDTH,num_spec=3)
    functions = [load_forward(ROOT/name) for name in ('baseline_qwen_gdn_linear_attn.py','qwen_gdn_linear_attn.py')]
    for prefill_len in (1,65,257):
        lens = [1,4,prefill_len,4]
        batch = BatchSpec(seq_lens=[81,84,prefill_len+32,100], query_lens=lens)
        common = create_common_attn_metadata(batch,16,torch.device('cuda'),arange_block_indices=True)
        common.block_table_tensor.add_(1)
        with set_current_vllm_config(cfg):
            builder = GDNAttentionMetadataBuilder(MambaSpec(block_size=16,shapes=((16,64),),dtypes=(torch.float16,)), [PREFIX],cfg,torch.device('cuda'))
            meta = builder.build(0,common,num_decode_draft_tokens_cpu=torch.tensor([-1,3,-1,3],dtype=torch.int32), num_accepted_tokens=torch.tensor([1,2,1,3],device='cuda',dtype=torch.int32))
        assert meta.num_spec_decodes == 2 and meta.num_prefills == 2
        assert meta.spec_token_indx.dtype == torch.int64
        pool = int(common.block_table_tensor.max())+1
        n = sum(lens)
        for state_dtype in (torch.bfloat16, torch.float32):
            conv0 = torch.randn(pool,*conv_shape,device='cuda',dtype=torch.bfloat16)*.05
            ssm0 = torch.randn(pool,*ssm_shape,device='cuda',dtype=state_dtype)*.05
            x = torch.randn(n,2*KD+VD,device='cuda',dtype=torch.bfloat16)*.1
            a = torch.randn(n,HV,device='cuda',dtype=torch.bfloat16)*.1
            b = torch.randn_like(a)*.1
            weight = torch.randn(2*KD+VD,1,WIDTH,device='cuda',dtype=torch.bfloat16)*.1
            bias = torch.randn(2*KD+VD,device='cuda',dtype=torch.bfloat16)*.1
            A_log = torch.randn(HV,device='cuda')*.1
            dt_bias = torch.randn(HV,device='cuda')*.1
            for strided in (False,True):
                outputs = []
                for fn, scope in functions:
                    conv, ssm = conv0.clone(),ssm0.clone()
                    layer = types.SimpleNamespace(prefix=PREFIX,enable_packed_recurrent_decode=False,tp_size=1,num_k_heads=H,num_v_heads=HV,head_k_dim=K,head_v_dim=V,key_dim=KD,value_dim=VD,activation='silu',A_log=A_log,dt_bias=dt_bias,conv1d=types.SimpleNamespace(weight=weight,bias=bias),kv_cache=(conv,ssm))
                    with set_current_vllm_config(cfg):
                        layer.chunk_gated_delta_rule = gdn.ChunkGatedDeltaRule()
                    layer.rearrange_mixed_qkv = types.MethodType(gdn.QwenGatedDeltaNetAttention.rearrange_mixed_qkv,layer)
                    backing = torch.full((n+3,HV,V*(2 if strided else 1)),-9,device='cuda',dtype=x.dtype)
                    out = backing[1:-1,:,::2] if strided else backing[1:-1]
                    scope['get_forward_context'] = lambda: types.SimpleNamespace(attn_metadata={PREFIX:meta})
                    def run():
                        return fn(layer,x.clone(),b,a,out)
                    run()
                    eager = (out.clone(),conv.clone(),ssm.clone())
                    for _ in range(3):
                        conv.copy_(conv0); ssm.copy_(ssm0); run()
                    conv.copy_(conv0); ssm.copy_(ssm0)
                    graph = torch.cuda.CUDAGraph()
                    with torch.cuda.graph(graph):
                        run()
                    conv.copy_(conv0); ssm.copy_(ssm0); out.fill_(-9)
                    graph.replay()
                    for actual,expected in zip((out,conv,ssm),eager):
                        torch.testing.assert_close(actual,expected,rtol=0,atol=0)
                    assert torch.all(out[n:]==-9)
                    assert torch.all(backing[[0,-1]]==-9)
                    if strided:
                        assert torch.all(backing[:,:,1::2]==-9)
                    outputs.append(eager)
                for baseline,patched in zip(*outputs):
                    torch.testing.assert_close(baseline,patched,rtol=0,atol=0)
                print(json.dumps({'prefill_len':prefill_len,'tokens':n,'state_dtype':str(state_dtype),'strided':strided,'output_equal':True,'conv_state_equal':True,'ssm_state_equal':True,'graph_matches_eager':True}),flush=True)
    print('12 real-kernel mixed-batch cases passed, including graph replay.',flush=True)

if __name__=='__main__':
    main()
