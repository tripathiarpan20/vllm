"""Fixed request batches, local streaming SLA measurements and output token IDs."""

import argparse
import asyncio
import hashlib
import json
import time
from pathlib import Path

import aiohttp
import numpy as np
from transformers import AutoTokenizer

ROOT = Path(__file__).parent
URL = "http://127.0.0.1:8000"


def requests():
    path = ROOT / "artifacts/requests.json"
    if path.exists():
        return json.loads(path.read_text())
    tok = AutoTokenizer.from_pretrained(ROOT / "model")
    tasks = [
        "Write a Python function that groups records by user ID and returns counts. Explain its time complexity.",
        "Summarize the service requirements in five bullet points and propose three tests.",
        "Explain how to diagnose high database latency and show a short SQL example.",
        "Write a concise incident response checklist for an inference service with rising queue latency.",
    ]
    context = (
        "The inference service receives requests from multiple clients. Each request has an identifier, a token budget, a priority, and a deadline. Operators record latency, resource use, cache hits, and errors. The database stores events in arrival order. A batch may include short and long prompts. Correctness checks compare outputs against a reference implementation. "
        * 200
    )
    data = []
    for i in range(32):
        n = [256, 768, 1536, 3072][i % 4]
        prefix = tok.encode(
            f"<|im_start|>user\nRequest {i:03d}. Context:\n" + context,
            add_special_tokens=False,
        )
        suffix = tok.encode(
            "\nTask: " + tasks[i % 4] + "\n<|im_end|>\n<|im_start|>assistant\n",
            add_special_tokens=False,
        )
        prompt = prefix[: n - len(suffix)] + suffix
        assert len(prompt) == n
        data.append(
            {"id": i, "prompt": prompt, "max_tokens": [32, 64, 96, 128][i % 4]}
        )
    path.write_text(json.dumps(data))
    return data


async def metric_text(session):
    async with session.get(URL + "/metrics") as r:
        r.raise_for_status()
        return await r.text()


async def one(session, req):
    start = time.perf_counter()
    events = []
    tokens = []
    usage = None
    body = {
        "model": "qwen-sampler",
        "prompt": req["prompt"],
        "max_tokens": req["max_tokens"],
        "temperature": 0,
        "seed": 42,
        "ignore_eos": True,
        "stream": True,
        "return_token_ids": True,
        "stream_options": {"include_usage": True},
    }
    try:
        async with session.post(URL + "/v1/completions", json=body) as r:
            if r.status != 200:
                raise RuntimeError(f"HTTP {r.status}: {(await r.text())[:400]}")
            async for raw in r.content:
                line = raw.decode().strip()
                if not line.startswith("data: "):
                    continue
                if line == "data: [DONE]":
                    break
                item = json.loads(line[6:])
                if item.get("usage"):
                    usage = item["usage"]
                for choice in item.get("choices", []):
                    ids = choice.get("token_ids") or []
                    if ids:
                        now = time.perf_counter()
                        events.append({"seconds": now - start, "tokens": len(ids)})
                        tokens.extend(ids)
        end = time.perf_counter()
        assert len(tokens) == req["max_tokens"], (len(tokens), req["max_tokens"], usage)
        return {
            "id": req["id"],
            "ok": True,
            "prompt_tokens": len(req["prompt"]),
            "token_ids": tokens,
            "events": events,
            "ttft_ms": events[0]["seconds"] * 1000,
            "latency_ms": (end - start) * 1000,
            "tpot_ms": (events[-1]["seconds"] - events[0]["seconds"])
            * 1000
            / (len(tokens) - events[0]["tokens"])
            if len(tokens) > events[0]["tokens"]
            else 0,
            "usage": usage,
        }
    except Exception as e:
        return {"id": req["id"], "ok": False, "error": str(e)}


async def execute(session, data, batch):
    rows = []
    start = time.perf_counter()
    for first in range(0, len(data), batch):
        rows.extend(
            await asyncio.gather(
                *[one(session, r) for r in data[first : first + batch]]
            )
        )
    return rows, time.perf_counter() - start


def percentile(values, p):
    return float(np.percentile(values, p)) if values else None


async def main(args):
    data = requests()
    digest = hashlib.sha256((ROOT / "artifacts/requests.json").read_bytes()).hexdigest()
    timeout = aiohttp.ClientTimeout(total=600)
    connector = aiohttp.TCPConnector(limit=64)
    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        if args.profile:
            async with session.post(URL + "/start_profile") as r:
                r.raise_for_status()
            rows, _ = await execute(session, [dict(r, max_tokens=8) for r in data[:8]], 8)
            async with session.post(URL + "/stop_profile") as r:
                r.raise_for_status()
            (ROOT / f"artifacts/{args.label}-profile-requests.json").write_text(
                json.dumps(rows)
            )
            print("profile complete", flush=True)
            return
        # Untimed warmup uses the same shape classes; every measured cell resets cache.
        warmup = [dict(r, max_tokens=16) for r in data[:32]]
        for batch in (1, 4, 8, 16, 32):
            async with session.post(URL + "/reset_prefix_cache") as r:
                r.raise_for_status()
            rows, _ = await execute(session, warmup, batch)
            assert all(r["ok"] for r in rows), rows
            print(f"WARMUP_COMPLETE: batch {batch}", flush=True)
        for rep in range(args.repeats):
            for batch in (1, 4, 8, 16, 32):
                async with session.post(URL + "/reset_prefix_cache") as r:
                    r.raise_for_status()
                before = await metric_text(session)
                rows, elapsed = await execute(session, data, batch)
                after = await metric_text(session)
                stem = ROOT / f"artifacts/{args.label}-r{rep}-b{batch}"
                stem.with_suffix(".requests.json").write_text(json.dumps(rows))
                Path(str(stem) + ".metrics-before.txt").write_text(before)
                Path(str(stem) + ".metrics-after.txt").write_text(after)
                good = [r for r in rows if r["ok"]]
                gaps = [
                    (b["seconds"] - a["seconds"]) * 1000
                    for r in good
                    for a, b in zip(r["events"], r["events"][1:])
                ]
                # Stream chunks may carry multiple MTP tokens. Keep chunk gaps and
                # explicitly labeled per-token-normalized intervals separately.
                normalized = [
                    (b["seconds"] - a["seconds"]) * 1000 / b["tokens"]
                    for r in good
                    for a, b in zip(r["events"], r["events"][1:])
                    for _ in range(b["tokens"])
                ]
                summary = {
                    "label": args.label,
                    "repeat": rep,
                    "batch_size": batch,
                    "requests": len(rows),
                    "success": len(good),
                    "elapsed_s": elapsed,
                    "output_tokens": sum(len(r["token_ids"]) for r in good),
                    "request_sha256": digest,
                    "p50_ttft_ms": percentile([r["ttft_ms"] for r in good], 50),
                    "p99_ttft_ms": percentile([r["ttft_ms"] for r in good], 99),
                    "p99_stream_gap_ms": percentile(gaps, 99),
                    "p99_normalized_token_interval_ms": percentile(normalized, 99),
                    "p99_tpot_ms": percentile([r["tpot_ms"] for r in good], 99),
                }
                summary["output_tokens_per_s"] = summary["output_tokens"] / elapsed
                summary["sla_pass"] = (
                    len(good) == len(rows)
                    and summary["p99_ttft_ms"] <= 2000
                    and summary["p99_stream_gap_ms"] <= 50
                )
                with (ROOT / "artifacts/sla-results.jsonl").open("a") as f:
                    f.write(json.dumps(summary) + "\n")
                print(json.dumps(summary), flush=True)
                if len(good) != len(rows):
                    raise RuntimeError("request errors; see raw results")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--label", required=True)
    p.add_argument("--repeats", type=int, default=2)
    p.add_argument("--profile", action="store_true")
    asyncio.run(main(p.parse_args()))
