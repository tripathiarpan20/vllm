"""Summarize sampling operations from separately captured serving profiles."""
from collections import Counter
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).parent
result = []
for path in sorted((ROOT / "artifacts/traces").rglob("*.json.gz")):
    with gzip.open(path, "rt") as f:
        trace = json.load(f)
    selected = Counter()
    gpu = Counter()
    for event in trace["traceEvents"]:
        name = event.get("name", "")
        if event.get("cat") == "cpu_op" and name in ("aten::argmax", "aten::gather"):
            shapes = event.get("args", {}).get("Input Dims", [])
            if any(isinstance(s, list) and len(s) == 2 and s[-1] == 243 for s in shapes):
                selected[(name, str(shapes))] += 1
        if event.get("cat") == "kernel" and "gumbel_sample" in name:
            gpu[name] += 1
    result.append(dict(file=str(path.relative_to(ROOT)),
                       final_cpu_ops=[dict(name=k[0], shapes=k[1], count=v) for k,v in selected.items()],
                       gumbel_gpu_kernels=dict(gpu)))
(ROOT / "artifacts/profile-summary.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
