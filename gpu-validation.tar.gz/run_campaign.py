"""Sequential ABBA server runs; no simultaneous GPU workloads."""

import json
import os
from pathlib import Path
import signal
import subprocess
import time
import urllib.request

ROOT = Path(__file__).parent
os.chdir(ROOT)


def health():
    try:
        with urllib.request.urlopen("http://127.0.0.1:8000/health", timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


if health():
    raise RuntimeError(
        "port 8000 is already serving; refusing to replace an unknown server"
    )

for variant, label in [
    ("baseline", "baseline-a"),
    ("patched", "patched-a"),
    ("patched", "patched-b"),
    ("baseline", "baseline-b"),
]:
    print(
        json.dumps(
            {"event": "start", "variant": variant, "label": label, "time": time.time()}
        ),
        flush=True,
    )
    with open(ROOT / f"artifacts/{label}-server.log", "w") as log:
        server = subprocess.Popen(
            ["bash", "start_server.sh", variant, label],
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            ready = False
            for _ in range(600):
                if server.poll() is not None:
                    raise RuntimeError(f"{label}: server exited {server.returncode}")
                if health():
                    ready = True
                    break
                time.sleep(2)
            if not ready:
                raise RuntimeError("server startup timed out")
            print(
                json.dumps({"event": "ready", "label": label, "time": time.time()}),
                flush=True,
            )
            with open(ROOT / f"artifacts/{label}-client.log", "w") as clientlog:
                subprocess.run(
                    [
                        ".venv/bin/python",
                        "sla_client.py",
                        "--label",
                        label,
                        "--repeats",
                        "2",
                    ],
                    stdout=clientlog,
                    stderr=subprocess.STDOUT,
                    check=True,
                    timeout=1800,
                )
            with open(ROOT / f"artifacts/{label}-eval.log", "w") as evallog:
                subprocess.run([".venv/bin/python", "eval_client.py", "--label", label],
                               stdout=evallog, stderr=subprocess.STDOUT,
                               check=True, timeout=900)
            if label in ("baseline-a", "patched-a"):
                with open(ROOT / f"artifacts/{label}-profile-client.log", "w") as profilelog:
                    subprocess.run(
                        [
                            ".venv/bin/python",
                            "sla_client.py",
                            "--label",
                            label + "-profile",
                            "--profile",
                        ],
                        stdout=profilelog,
                        stderr=subprocess.STDOUT,
                        check=True,
                        timeout=300,
                    )
            print(
                json.dumps({"event": "finished", "label": label, "time": time.time()}),
                flush=True,
            )
        finally:
            if server.poll() is None:
                os.killpg(server.pid, signal.SIGTERM)
                try:
                    server.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    os.killpg(server.pid, signal.SIGKILL)
                    server.wait()
            time.sleep(5)
print("CAMPAIGN_COMPLETE", flush=True)
