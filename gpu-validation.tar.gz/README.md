# H100 GPU validation evidence

This bundle records validation of commit `5fe281e336f8f25aab2f89cf85c211bf83594551` against vLLM base `0f8fa53acf43a9a6a7a1f7e6b196950c78cd6d7a` on September 16, 2026. `PR_DESCRIPTION.md`, supplied separately, contains the reviewer-facing results.

## What is measured

- `pytest.log`: the normal repository runner, with 8 output assembly tests and 18 existing GPU recurrent-kernel tests.
- `gpu_forward_core_check.py` / `forward-core.log`: baseline and patched Python forward methods with real convolution, GDN, and metadata kernels. Twelve cases compare outputs, convolution states, and recurrent states exactly, including CUDA graph replay and padding. A small layer wrapper supplies weights/state; this is a component test, not a complete model accuracy test.
- `benchmark_gdn_output_scatter.py` / `assembly.jsonl`: isolated output merge timings, separate from serving. CUDA events, 25 warmup calls, 50 repetitions of 20 merges, medians, with and without CUDA graph replay. BF16/FP32, contiguous/strided output, 32 value heads of dimension 128, int64 indices as produced by mixed-batch metadata. The 4,096-token microbenchmark exceeds the serving run's 1,024-token scheduling budget and is only a larger tensor case.
- `sla_client.py`, `run_campaign.py`, and `start_server.sh`: identical requests submitted in waves of 1, 4, 8, 16, or 32. These are client batch sizes; the scheduler controls actual internal token batches. Four server sessions run in baseline/patched/patched/baseline order, two measured repetitions each. Server startup and a 32-request, 16-output-token warmup are outside timing; prefix cache is reset before every measured cell.
- `requests.json`: the exact 64 token-ID prompts, requested output lengths, and ordering shared by every run. There are 16 requests at each prompt/output length pair: 256/64, 768/128, 1536/192, and 3,072/256. Greedy generation, seed 42, `ignore_eos=true`; these fixed-length synthetic prompts are not a task accuracy benchmark.
- `*.requests.json`: request-level token IDs, token-bearing stream arrival events, latency, and usage. `*.metrics-before/after.txt`: Prometheus counter snapshots for speculative decoding. `sla-results.jsonl`: one row per measured repetition and batch size. `summary.json`: aggregate results from `analyze_results.py`.

The SLA criterion is 100% successful requests, p99 TTFT <= 2,000 ms, and p99 gap between token-bearing stream chunks <= 50 ms in every measured repetition. MTP can return multiple tokens in a chunk; the chunk-gap metric is not individual-token ITL. Normalized token intervals and per-request TPOT are also retained separately. Percentiles use NumPy's default linear interpolation. The report uses the worst per-run p99 across four repetitions per variant/batch size, and median throughput with full min/max range. This finite loopback test does not establish a production SLA under network load or sustained arrivals.

## Reproduction

The executed scripts expect `/workspace/pareton-gdn-review`, a Python environment at `.venv`, a model snapshot at `model`, and logs under `artifacts`. They bind to loopback port 8000. `run_campaign.py` refuses to start if that port already serves a health endpoint. Use a dedicated directory/port and idle GPU. The controller switches the single source module in this isolated environment and stops only servers it starts.

1. Install the wheel built from the exact baseline commit:
   `https://wheels.vllm.ai/0f8fa53acf43a9a6a7a1f7e6b196950c78cd6d7a/vllm-0.29.1rc1.dev194%2Bg0f8fa53ac-cp38-abi3-manylinux_2_28_x86_64.whl`.
   The wheel's unmodified GDN source was checked byte-for-byte against the baseline. The patched arm replaces only `vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py`; native binaries and all other dependencies are shared. See `pip-freeze-final.txt` and `runtime.json` for package versions.
2. Save the baseline module as `baseline_qwen_gdn_linear_attn.py` and the patched module as `qwen_gdn_linear_attn.py`. Check out the base repository plus the patch into `test-checkout` for its test helpers and tests.
3. Download `Qwen/Qwen3.5-4B` at revision `851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a` into `model`.
4. Copy the scripts and fixed `requests.json` into the directory and `artifacts` respectively. Preserve existing results in a separate directory before a rerun, because the client appends to `sla-results.jsonl`.
5. Run `.venv/bin/python run_campaign.py`, then `.venv/bin/python analyze_results.py`.

The full serving command is in `start_server.sh`. Torch compilation and default full/piecewise CUDA graphs remain enabled. `VLLM_USE_V2_MODEL_RUNNER=0` selects the runner containing this change. The profiler is activated only for a separate, untimed 8-request baseline run after the first session's measurements. Its trace is used to establish execution of the changed mixed-output branch; profiler latencies are excluded.

For the normal tests, run from `test-checkout`:

```bash
../.venv/bin/python -m pytest \
  tests/model_executor/test_gdn_output.py \
  tests/kernels/test_fused_sigmoid_gating_delta_rule.py -q
```

For the supplementary component checks, run from the evidence directory:

```bash
.venv/bin/python gpu_forward_core_check.py
.venv/bin/python benchmark_gdn_output_scatter.py \
  --device cuda --tokens 32 256 4096 --heads 32 --dim 128 --repeats 50
```

## Environment setup

The VM initially lacked a usable CUDA compiler setup for FlashInfer's sampler JIT. Before measured serving, the isolated environment was configured with CUDA 13.0 components: NVCC/CRT/NVVM/NVRTC 13.0.88, runtime 13.0.96, and CCCL 13.0.85. Within the CUDA wheel directory, `lib64` was linked to `lib`, and `lib/libcudart.so` to `libcudart.so.13`. `CUDA_HOME` and `PATH` are set in the launcher. The direct sampler smoke test passed before the first serving session. Setup failures are not benchmark samples.

No external traffic was used. SSH connection details, credentials, and unrelated service logs are excluded from this bundle.

`model-snapshot.json` verifies the pinned revision in all 14 downloaded-file metadata records. `final-audit.json` records the final manifest, count, source, and cache-reset checks.
