#!/bin/bash
set -euo pipefail
cd /workspace/pareton-gdn-review
export PATH="/workspace/pareton-gdn-review/.venv/bin:/workspace/pareton-gdn-review/.venv/lib/python3.12/site-packages/nvidia/cu13/bin:$PATH"
variant=${1:?baseline or patched}
label=${2:?run label}
module=.venv/lib/python3.12/site-packages/vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py
case "$variant" in
  baseline) cp baseline_qwen_gdn_linear_attn.py "$module" ;;
  patched) cp qwen_gdn_linear_attn.py "$module" ;;
  *) exit 2 ;;
esac
sha256sum "$module" > "artifacts/${label}-module.sha256"
exec env CUDA_HOME=/workspace/pareton-gdn-review/.venv/lib/python3.12/site-packages/nvidia/cu13 VLLM_USE_V2_MODEL_RUNNER=0 VLLM_SERVER_DEV_MODE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 \
  .venv/bin/vllm serve /workspace/pareton-gdn-review/model \
  --served-model-name qwen-gdn --host 127.0.0.1 --port 8000 \
  --dtype bfloat16 --tensor-parallel-size 1 --seed 42 \
  --max-model-len 4096 --max-num-seqs 32 --max-num-batched-tokens 1024 \
  --gpu-memory-utilization 0.80 --enable-prefix-caching --enable-chunked-prefill \
  --gdn-prefill-backend triton --mamba-cache-mode align \
  --speculative-config '{"method":"mtp","num_speculative_tokens":3}' \
  --generation-config vllm --language-model-only \
  --profiler-config '{"profiler":"torch","torch_profiler_dir":"/workspace/pareton-gdn-review/artifacts/traces","torch_profiler_with_stack":false,"torch_profiler_record_shapes":true,"ignore_frontend":true}'
