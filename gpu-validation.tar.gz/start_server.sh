#!/bin/bash
set -euo pipefail
cd /workspace/pareton-sampler-review
export PATH="$PWD/.venv/bin:$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13/bin:$PATH"
export LIBRARY_PATH="$PWD/cuda-link-libs${LIBRARY_PATH:+:$LIBRARY_PATH}"
export LD_LIBRARY_PATH="$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
variant=${1:?baseline or patched}
label=${2:?run label}
module=runtime-src/vllm/v1/worker/gpu/sample/gumbel.py
case "$variant" in
  baseline) cp baseline_gumbel.py "$module" ;;
  patched) cp patched_gumbel.py "$module" ;;
  *) exit 2 ;;
esac
sha256sum "$module" > "artifacts/${label}-module.sha256"
exec env CUDA_HOME="$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13" VLLM_DEEP_GEMM_WARMUP=skip VLLM_USE_V2_MODEL_RUNNER=1 VLLM_SERVER_DEV_MODE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 \
  .venv/bin/vllm serve "$PWD/model" \
  --served-model-name qwen-sampler --host 127.0.0.1 --port 8000 \
  --dtype bfloat16 --tensor-parallel-size 1 --seed 42 \
  --max-model-len 4096 --max-num-seqs 32 --max-num-batched-tokens 1024 \
  --gpu-memory-utilization 0.80 --enable-prefix-caching --enable-chunked-prefill \
  --gdn-prefill-backend triton --mamba-cache-mode align \
  --generation-config vllm --language-model-only \
  --profiler-config '{"profiler":"torch","torch_profiler_dir":"/workspace/pareton-sampler-review/artifacts/traces","torch_profiler_with_stack":false,"torch_profiler_record_shapes":true,"ignore_frontend":true}'
