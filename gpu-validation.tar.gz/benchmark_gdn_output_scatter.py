"""Compare old and new GDN mixed-output assembly; no GDN kernels or model load.

Run with a CUDA-enabled PyTorch installation. CPU mode validates semantics only.
"""

import argparse
import json
import statistics
from functools import partial

import torch


def legacy(out, spec, non_spec, spec_idx, non_spec_idx):
    n = spec.shape[1] + non_spec.shape[1]
    merged = torch.empty((1, n, *spec.shape[2:]), dtype=out.dtype, device=out.device)
    merged.index_copy_(1, spec_idx, spec)
    merged.index_copy_(1, non_spec_idx, non_spec)
    out[:n] = merged.squeeze(0)


def direct(out, spec, non_spec, spec_idx, non_spec_idx):
    out.index_copy_(0, spec_idx, spec.squeeze(0))
    out.index_copy_(0, non_spec_idx, non_spec.squeeze(0))


def cuda_time(fn, repeats, graph):
    for _ in range(25):
        fn()
    torch.cuda.synchronize()
    if graph:
        captured = torch.cuda.CUDAGraph()
        with torch.cuda.graph(captured):
            for _ in range(20):
                fn()
        run = captured.replay
    else:

        def run():
            for _ in range(20):
                fn()

    samples = []
    start, end = (
        torch.cuda.Event(enable_timing=True),
        torch.cuda.Event(enable_timing=True),
    )
    for _ in range(repeats):
        start.record()
        run()
        end.record()
        end.synchronize()
        samples.append(start.elapsed_time(end) * 1000 / 20)
    return statistics.median(samples)


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--tokens", type=int, nargs="+", default=[32, 256, 4096])
    parser.add_argument("--heads", type=int, default=32)
    parser.add_argument("--dim", type=int, default=128)
    parser.add_argument("--repeats", type=int, default=50)
    args = parser.parse_args()
    if min(*args.tokens, args.heads, args.dim, args.repeats) < 1:
        parser.error("all sizes and repeats must be positive")
    if args.device == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA unavailable; use --device cpu for semantic checks only")
    torch.manual_seed(0)
    print(
        json.dumps(
            {
                "torch": torch.__version__,
                "cuda": torch.version.cuda,
                "device": torch.cuda.get_device_name()
                if args.device == "cuda"
                else "cpu",
                "scope": "output assembly only; no end-to-end speedup claim",
            }
        )
    )
    for n in args.tokens:
        for dtype in (torch.bfloat16, torch.float32):
            for strided in (False, True):
                idx = torch.randperm(n, device=args.device)
                # Mixed batches use argsort's int64 indices; uniform speculative
                # graph buffers use int32 but do not enter the mixed-output merge.
                spec_idx, non_spec_idx = idx[: n // 2], idx[n // 2 :]
                expected = torch.randn(
                    n, args.heads, args.dim, device=args.device, dtype=dtype
                )
                spec = expected.index_select(0, spec_idx).unsqueeze(0)
                non_spec = expected.index_select(0, non_spec_idx).unsqueeze(0)
                buffers = [
                    torch.full(
                        (n + 4, args.heads, args.dim * (2 if strided else 1)),
                        -9,
                        dtype=dtype,
                        device=args.device,
                    )
                    for _ in range(2)
                ]
                outs = [x[1:-1, :, ::2] if strided else x[1:-1] for x in buffers]
                calls = [
                    partial(f, o, spec, non_spec, spec_idx, non_spec_idx)
                    for f, o in zip((legacy, direct), outs)
                ]
                for call, out, backing in zip(calls, outs, buffers):
                    call()
                    torch.testing.assert_close(out[:n], expected, rtol=0, atol=0)
                    assert torch.all(out[n:] == -9)
                    assert torch.all(backing[[0, -1]] == -9)
                    if strided:
                        assert torch.all(backing[:, :, 1::2] == -9)
                result = {
                    "tokens": n,
                    "heads": args.heads,
                    "dim": args.dim,
                    "dtype": str(dtype),
                    "strided": strided,
                    "correct": True,
                    "temporary_bytes_removed": n
                    * args.heads
                    * args.dim
                    * expected.element_size(),
                }
                if args.device == "cuda":
                    for graph in (False, True):
                        key = "graph_us" if graph else "eager_us"
                        result[key] = dict(
                            zip(
                                ("legacy", "direct"),
                                [cuda_time(c, args.repeats, graph) for c in calls],
                            )
                        )
                    # Also verify output after captured replay.
                    torch.testing.assert_close(outs[0], outs[1], rtol=0, atol=0)
                print(json.dumps(result))


if __name__ == "__main__":
    main()
