"""Run analysis and archive the completed campaign, with no GPU workload."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

ROOT = Path(__file__).parent
ART = ROOT / 'artifacts'
for _ in range(120):
    if (ART / 'campaign.log').read_text().strip().endswith('CAMPAIGN_COMPLETE'):
        break
    time.sleep(5)
else:
    raise RuntimeError('Campaign did not finish; not archiving incomplete results')
subprocess.run([str(ROOT / '.venv/bin/python'), str(ROOT / 'analyze_results.py')], check=True, stdout=(ART / 'analysis.log').open('w'))
# Assertions separate recorded data from claims in the reviewer-facing report.
labels = ['baseline-a','patched-a','patched-b','baseline-b']
audit = {}
for label in labels:
    log = (ART / f'{label}-server.log').read_text()
    start = log.find('POST /reset_prefix_cache HTTP')
    assert start >= 0
    measured = log[start:]
    if label == 'baseline-a':
        measured = measured.split('POST /start_profile HTTP')[0]
    audit[label] = {
        'jit_warnings_after_first_measured_reset': measured.count('Triton kernel JIT compilation'),
        'source_sha256_record': (ART / f'{label}-module.sha256').read_text().strip(),
    }
assert len({(ART / f'{label}-module.sha256').read_text().split()[0] for label in ['baseline-a','baseline-b']}) == 1
assert len({(ART / f'{label}-module.sha256').read_text().split()[0] for label in ['patched-a','patched-b']}) == 1
assert (ART / 'baseline-a-module.sha256').read_text().split()[0] != (ART / 'patched-a-module.sha256').read_text().split()[0]
(ART / 'measurement-audit.json').write_text(json.dumps(audit,indent=2))
subprocess.run([str(ROOT / '.venv/lib/python3.12/site-packages/nvidia/cu13/bin/nvcc'), '--version'],check=True,stdout=(ART/'nvcc-version-final.txt').open('w'))
subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv'],check=True,stdout=(ART/'gpu-processes-after.txt').open('w'))
files = []
for pattern in ['*.requests.json','*.metrics-before.txt','*.metrics-after.txt','*-module.sha256','*-server.log','*-client.log']:
    files.extend(p for p in ART.glob(pattern) if p.name.startswith(tuple(labels+['profile'])))
for name in ['assembly.jsonl','assembly.stderr','forward-core.log','pytest.log','gpu-info.csv','vm-details.txt','runtime.json','pip-freeze-final.txt','nvcc-version-final.txt','requests.json','sla-results.jsonl','summary.json','campaign.log','trace-summary.json','measurement-audit.json','gpu-processes-after.txt','sampler-smoke-pass.log','baseline-profile-profile-requests.json']:
    files.append(ART/name)
files.extend((ART/'traces').rglob('*'))
for name in ['README.md','sla_client.py','run_campaign.py','start_server.sh','gpu_forward_core_check.py','benchmark_gdn_output_scatter.py','analyze_results.py','analyze_trace.py','collect_evidence.py','baseline_qwen_gdn_linear_attn.py','qwen_gdn_linear_attn.py','gdn-direct-output-scatter.patch']:
    files.append(ROOT/name)
files=sorted(set(p for p in files if p.is_file()))
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(ROOT/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2))
files.append(ROOT/'SHA256SUMS.json')
with tarfile.open(ROOT/'gpu-validation.tar.gz','w:gz') as tar:
    for p in files:
        tar.add(p,arcname=str(p.relative_to(ROOT)))
print(json.dumps({'archive_bytes':(ROOT/'gpu-validation.tar.gz').stat().st_size,'files':len(files),'audit':audit}),flush=True)
