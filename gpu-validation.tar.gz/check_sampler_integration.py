"""Exact public-sampler parity with nontrivial mappings, strides and caches."""
import importlib.util
import json
from pathlib import Path

import torch
from vllm.v1.worker.gpu.sample import gumbel as patched

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location("baseline_gumbel", ROOT / "baseline_gumbel.py")
baseline = importlib.util.module_from_spec(spec)
spec.loader.exec_module(baseline)
torch.manual_seed(91)
cases = 0
for dtype in (torch.float32, torch.bfloat16, torch.float16):
    for fp64 in (False, True):
        for drafting in (False, True):
            for vocab in (1023, 1025, 248320):
                # A strided row layout and a request mapping with repeated entries.
                logits = torch.randn(12, vocab, dtype=dtype, device="cuda")[::2]
                mapping = torch.tensor([3, 0, 2, 1, 3, 0], dtype=torch.int32, device="cuda")
                temp = torch.tensor([0, 0.5, 1, 1.7], device="cuda")
                seed = torch.tensor([42, -1, 2**62, 123], dtype=torch.int64, device="cuda")
                pos = torch.tensor([4, 11, 100, 2, 5, 12], dtype=torch.int64, device="cuda")
                cols = torch.tensor([0, 0, 1, 1, 2, 2], dtype=torch.int32, device="cuda")
                caches = [torch.full((4, 3, vocab + 7), -17., device="cuda", dtype=dtype) for _ in range(2)]
                outputs = []
                for impl, cache in zip((baseline, patched), caches):
                    outputs.append(impl.gumbel_sample(logits, mapping, temp, seed, pos,
                        apply_temperature=True, is_drafting=drafting, use_fp64=fp64,
                        logits_cache=cache, logits_cache_col=cols))
                assert torch.equal(*outputs)
                assert torch.equal(*caches)
                assert all(torch.equal(cache[..., vocab:], torch.full_like(cache[..., vocab:], -17.)) for cache in caches)
                cases += 1
print(json.dumps(dict(public_sampler_cases=cases, exact_tokens=True, exact_cache=True, padding_preserved=True)))
