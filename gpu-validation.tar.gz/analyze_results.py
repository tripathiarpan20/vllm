import hashlib
import json
import re
import statistics
from pathlib import Path

import numpy as np

ROOT = Path(__file__).parent
ART = ROOT / "artifacts"
records = [
    json.loads(line) for line in (ART / "sla-results.jsonl").read_text().splitlines()
]
assert len(records) == 40, len(records)
manifest_hash = hashlib.sha256((ART / "requests.json").read_bytes()).hexdigest()
assert all(r["request_sha256"] == manifest_hash for r in records)
assert len({(r["label"], r["repeat"], r["batch_size"]) for r in records}) == 40
assert all(r["requests"] == r["success"] == 32 for r in records)
assert all(r["output_tokens"] == 2560 for r in records)

names = ("num_drafts", "num_draft_tokens", "num_accepted_tokens")


def metrics(path):
    text = path.read_text()
    return {
        key: sum(
            float(v)
            for v in re.findall(
                r"^vllm:spec_decode_" + key + r"_total\{[^\n]*\}\s+(\S+)", text, re.M
            )
        )
        for key in names
    }


def rows(label, rep, b):
    return json.loads((ART / f"{label}-r{rep}-b{b}.requests.json").read_text())


def equal(a, b):
    return a["ok"] and b["ok"] and a["token_ids"] == b["token_ids"]


summary = []
parity = []
for b in (1, 4, 8, 16, 32):
    baseline = rows("baseline-a", 0, b)
    for label in ("baseline-a", "patched-a", "patched-b", "baseline-b"):
        for rep in (0, 1):
            tested = rows(label, rep, b)
            assert [x["id"] for x in tested] == [x["id"] for x in baseline]
            parity.append(
                {
                    "batch": b,
                    "label": label,
                    "rep": rep,
                    "identical_requests": sum(
                        equal(a, c) for a, c in zip(baseline, tested)
                    ),
                    "total": len(tested),
                    "matched_tokens": sum(
                        sum(
                            x == y
                            for x, y in zip(
                                a.get("token_ids", []), c.get("token_ids", [])
                            )
                        )
                        for a, c in zip(baseline, tested)
                    ),
                    "tokens": sum(len(x.get("token_ids", [])) for x in tested),
                }
            )
    for variant in ("baseline", "patched"):
        cells = [
            r
            for r in records
            if r["batch_size"] == b and r["label"].startswith(variant)
        ]
        assert len(cells) == 4
        flat = []
        delta = {n: 0 for n in names}
        for cell in cells:
            flat += rows(cell["label"], cell["repeat"], b)
            stem = f"{cell['label']}-r{cell['repeat']}-b{b}"
            before = metrics(ART / f"{stem}.metrics-before.txt")
            after = metrics(ART / f"{stem}.metrics-after.txt")
            for n in names:
                delta[n] += after[n] - before[n]
        rates = [x["output_tokens_per_s"] for x in cells]
        summary.append(
            {
                "variant": variant,
                "batch_size": b,
                "requests": len(flat),
                "success": sum(x["ok"] for x in flat),
                "output_tokens": sum(len(x.get("token_ids", [])) for x in flat),
                "median_tok_s": statistics.median(rates),
                "min_tok_s": min(rates),
                "max_tok_s": max(rates),
                "worst_p99_ttft_ms": max(x["p99_ttft_ms"] for x in cells),
                "worst_p99_stream_gap_ms": max(x["p99_stream_gap_ms"] for x in cells),
                "worst_p99_normalized_interval_ms": max(
                    x["p99_normalized_token_interval_ms"] for x in cells
                ),
                "pooled_p99_ttft_ms": float(
                    np.percentile([x["ttft_ms"] for x in flat if x["ok"]], 99)
                ),
                "sla_pass_all_repetitions": all(x["sla_pass"] for x in cells),
                "spec_counters": delta,
                "acceptance_rate": delta["num_accepted_tokens"]
                / delta["num_draft_tokens"]
                if delta["num_draft_tokens"]
                else None,
                "acceptance_length": 1
                + delta["num_accepted_tokens"] / delta["num_drafts"]
                if delta["num_drafts"]
                else None,
            }
        )
result = {
    "request_sha256": hashlib.sha256((ART / "requests.json").read_bytes()).hexdigest(),
    "summary": summary,
    "parity": parity,
    "total_requests": sum(x["requests"] for x in records),
    "total_success": sum(x["success"] for x in records),
    "total_output_tokens": sum(x["output_tokens"] for x in records),
}
(ART / "summary.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
