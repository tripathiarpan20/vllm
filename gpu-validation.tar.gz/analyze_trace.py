"""Summarize the untimed baseline trace's mixed GDN output merges."""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).parent
paths = sorted((ROOT / 'artifacts/traces').rglob('*.json*'))
assert paths, 'No profiler traces found'
reports = []
for path in paths:
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt') as f:
        trace = json.load(f)
    merges = collections.Counter()
    operations = collections.Counter()
    for event in trace.get('traceEvents', []):
        name = event.get('name', '')
        if 'qwen_gdn_attention_core' in name:
            operations[name] += 1
        if name != 'aten::index_copy_':
            continue
        args = event.get('args', {})
        dims = args.get('Input Dims', args.get('Input Shapes', []))
        if dims and len(dims[0]) == 4 and dims[0][0] == 1 and dims[0][-2:] == [32, 128]:
            merges[tuple(dims[0])] += 1
    reports.append({
        'trace': path.name,
        'events': len(trace.get('traceEvents', [])),
        'gdn_operations': dict(operations),
        'mixed_output_index_copy_calls': sum(merges.values()),
        'mixed_output_shapes': [{'shape': list(k), 'calls': v} for k, v in sorted(merges.items())],
    })
assert sum(r['mixed_output_index_copy_calls'] for r in reports) > 0, reports
result = {'scope': 'Untimed 8-request baseline profile; 4D [1,N,32,128] index_copy destinations identify the legacy mixed-output merge.', 'reports': reports}
(ROOT / 'artifacts/trace-summary.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
