"""Compare both samplers on identical live Qwen logits; never use for timing."""
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import urllib.request

ROOT = Path(__file__).parent
os.chdir(ROOT)
marker=ROOT/'enable_live_parity'
marker.unlink(missing_ok=True)
module=ROOT/'runtime-src/vllm/v1/worker/gpu/sample/gumbel.py'
wrapper='''
# Supplementary validation instrumentation, never part of the production patch.
import importlib.util as _validation_importlib
import os as _validation_os
import sys as _validation_sys
_validation_spec = _validation_importlib.spec_from_file_location(
    "_validation_baseline_gumbel", "/workspace/pareton-sampler-review/baseline_gumbel.py")
_validation_baseline = _validation_importlib.module_from_spec(_validation_spec)
_validation_sys.modules[_validation_spec.name] = _validation_baseline
_validation_spec.loader.exec_module(_validation_baseline)
_validation_patched = gumbel_sample
_validation_calls = 0
_validation_rows = 0

def gumbel_sample(*args, **kwargs):
    global _validation_calls, _validation_rows
    result = _validation_patched(*args, **kwargs)
    if _validation_os.path.exists("/workspace/pareton-sampler-review/enable_live_parity"):
        assert kwargs.get("logits_cache") is None
        expected = _validation_baseline.gumbel_sample(*args, **kwargs)
        if not torch.equal(result, expected):
            raise AssertionError("LIVE_SAMPLER_MISMATCH")
        _validation_calls += 1
        _validation_rows += result.numel()
        print(f"LIVE_SAMPLER_PARITY: calls={_validation_calls} rows={_validation_rows}", flush=True)
    return result
'''
(ROOT/'live_gumbel.py').write_text((ROOT/'patched_gumbel.py').read_text()+wrapper)
launcher=(ROOT/'start_server.sh').read_text().replace('patched) cp patched_gumbel.py', 'patched) cp live_gumbel.py')
(ROOT/'start_live_server.sh').write_text(launcher)
try:
    with urllib.request.urlopen('http://127.0.0.1:8000/health', timeout=3) as r:
        if r.status == 200:
            raise RuntimeError('Refusing to replace an existing server')
except (OSError, urllib.error.URLError):
    pass
with (ROOT/'artifacts/live-parity-server.log').open('w') as log:
    server=subprocess.Popen(['bash','start_live_server.sh','patched','live-parity'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        for _ in range(600):
            if server.poll() is not None:
                raise RuntimeError(f'validation server exited {server.returncode}')
            try:
                with urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=3) as r:
                    if r.status==200:
                        break
            except Exception:
                pass
            time.sleep(2)
        else:
            raise RuntimeError('validation server startup timed out')
        marker.touch()
        with (ROOT/'artifacts/live-parity-client.log').open('w') as out:
            subprocess.run(['.venv/bin/python','eval_client.py','--label','live-parity'],stdout=out,stderr=subprocess.STDOUT,check=True,timeout=900)
    finally:
        marker.unlink(missing_ok=True)
        if server.poll() is None:
            os.killpg(server.pid,signal.SIGTERM)
            try:
                server.wait(timeout=60)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid,signal.SIGKILL)
                server.wait()
        module.write_text((ROOT/'patched_gumbel.py').read_text())
import re
log=(ROOT/'artifacts/live-parity-server.log').read_text()
counts=re.findall(r'LIVE_SAMPLER_PARITY: calls=(\d+) rows=(\d+)',log)
assert counts and int(counts[-1][1])>=24*64, counts[-1:]
assert 'LIVE_SAMPLER_MISMATCH' not in log
result=dict(calls=int(counts[-1][0]),rows=int(counts[-1][1]),exact=True,requests=24,generated_tokens=1536)
(ROOT/'artifacts/live-parity-summary.json').write_text(json.dumps(result,indent=2))
print('LIVE_PARITY_COMPLETE',json.dumps(result),flush=True)
