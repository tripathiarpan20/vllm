"""Generate the PR result tables from the recorded benchmark evidence."""
import hashlib
import json
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).parent
ART = ROOT / 'artifacts'
summary = json.loads((ART / 'summary.json').read_text())
evals = json.loads((ART / 'eval-summary.json').read_text())
profiles = json.loads((ART / 'profile-summary.json').read_text())
live = json.loads((ART / 'live-parity-summary.json').read_text())
assert live['exact'] and live['rows'] >= 1536
kernels = [json.loads(s) for s in (ART / 'kernel-bench.jsonl').read_text().splitlines()]
assert summary['total_requests'] == summary['total_success'] == 1280
assert summary['total_output_tokens'] == 102400
assert len(kernels) == 168
for label in ('baseline-a', 'patched-a', 'patched-b', 'baseline-b'):
    source = ROOT / ('baseline_gumbel.py' if label.startswith('baseline') else 'patched_gumbel.py')
    expected = hashlib.sha256(source.read_bytes()).hexdigest()
    assert (ART / f'{label}-module.sha256').read_text().split()[0] == expected
assert len(profiles) == 2
baseline_ops = sum(x['count'] for x in profiles[0]['final_cpu_ops'] if x['name'] == 'aten::argmax')
patched_ops = sum(x['count'] for x in profiles[1]['final_cpu_ops'])
assert baseline_ops > 0 and patched_ops == 0
fused_calls = sum(v for k,v in profiles[1]['gumbel_gpu_kernels'].items() if 'reduce_kernel' in k)
assert fused_calls > 0
lines = ['## Test Result', '', '### Correctness and static checks', '',
'| Check | Result |', '| --- | --- |',
'| Existing GPU Gumbel suite plus new reduction regressions | **30 passed** |',
'| Targeted watermark fallback and Gumbel-drafted rejection sampling | **4 passed**, 74 unrelated cases deselected |',
'| Supplementary baseline/patched public-sampler matrix | **36 passed**, exact token and cache equality; padding preserved |',
'| New CUDA-graph replay regression cases | All eight passed after mutating values and mappings |',
'| Kernel benchmark equivalence checks | Exact baseline/patched sampled IDs for all 42 full-sampler shapes and all 42 final-reduction shapes |',
'| Applicable pre-commit hooks, default mypy and explicit Python 3.12 mypy | Passed |',
'| Patch whitespace and final source hashes | Passed |',
f"| Both samplers on identical live Qwen logits | **{live['calls']:,} calls / {live['rows']:,} rows matched exactly**, during 24 additional seeded requests |", '',
'### Isolated kernel timing', '',
'CUDA-event timings in microseconds at the Qwen vocabulary size of **248,320**. Values are the average of the two measurement-order medians. The complete matrix, including eager execution, is retained in `kernel-bench.jsonl`.', '',
'| Rows | Final reduction, graph FP32 baseline → patched (µs) | Full sampler, graph FP32 baseline → patched (µs) | Full sampler, graph FP64 baseline → patched (µs) |',
'| --- | --- | --- | --- |']

def pair(stage, rows, fp64, graph=True):
    r = next(r for r in kernels if r['stage']==stage and r['rows']==rows and r['fp64']==fp64 and r['graph']==graph and r['vocab']==248320)
    return tuple(statistics.median(p[k]['median_us'] for p in r['pairs']) for k in ('old','new'))

def fmt(p):
    return f'{p[0]:.2f} → {p[1]:.2f}'

for rows in (1,4,8,16,32,128,512):
    lines.append(f'| {rows} | {fmt(pair("reduce", rows, False))} | {fmt(pair("full", rows, False))} | {fmt(pair("full", rows, True))} |')
lines += ['', '| Rows | Final reduction, eager FP32 baseline → patched (µs) | Full sampler, eager FP32 baseline → patched (µs) |', '| --- | --- | --- |']
for rows in (1,8,32,512):
    lines.append(f'| {rows} | {fmt(pair("reduce", rows, False, False))} | {fmt(pair("full", rows, False, False))} |')
ratios = {}
for stage in ('reduce','full'):
    for graph in (False,True):
        group = [r for r in kernels if r['stage']==stage and r['graph']==graph]
        values = [statistics.median(p['old']['median_us'] for p in r['pairs']) / statistics.median(p['new']['median_us'] for p in r['pairs']) for r in group]
        ratios[(stage,graph)] = (min(values),max(values))
a,b=ratios[('reduce',True)];c,d=ratios[('full',True)];e,f=ratios[('full',False)]
lines += ['', f'Across the entire shape/precision matrix, the graph-executed final reduction is **{a:.2f}–{b:.2f}× faster**. Complete graph-executed sampling ranges from **{c:.3f}–{d:.2f}×**; complete eager sampling ranges from **{e:.3f}–{f:.2f}×**, including a small slower observation at the large-work end. The saving is a few microseconds per sampler call, and becomes a small fraction of total work at large row counts. These are kernel measurements, not model throughput ratios.', '',
'### Serving throughput and latency', '',
'All **1,280/1,280 measured requests succeeded**, producing **102,400 tokens** across the four server sessions.', '',
'| Client concurrency | Baseline output tok/s, median [min–max] | Patched output tok/s, median [min–max] | Median change |',
'| --- | --- | --- | --- |']
lookup = {(r['variant'],r['batch_size']):r for r in summary['summary']}
changes=[]
for batch in (1,4,8,16,32):
    a,b=lookup['baseline',batch],lookup['patched',batch]
    change=(b['median_tok_s']/a['median_tok_s']-1)*100
    changes.append(change)
    def rate(r): return f"{r['median_tok_s']:.2f} [{r['min_tok_s']:.2f}–{r['max_tok_s']:.2f}]"
    lines.append(f'| {batch} | {rate(a)} | {rate(b)} | {change:+.2f}% |')
lines += ['', '| Client concurrency | Worst p99 TTFT, baseline → patched (ms) | Worst p99 stream interval, baseline → patched (ms) |', '| --- | --- | --- |']
for batch in (1,4,8,16,32):
    a,b=lookup['baseline',batch],lookup['patched',batch]
    lines.append(f"| {batch} | {a['worst_p99_ttft_ms']:.1f} → {b['worst_p99_ttft_ms']:.1f} | {a['worst_p99_stream_gap_ms']:.1f} → {b['worst_p99_stream_gap_ms']:.1f} |")
lines += ['', 'The p99 columns report the worst of four finite, 32-request repetitions. They are workload observations, not production tail-latency guarantees. The raw data retains every measured request and all streaming events.', '',
'### Generated-output comparisons', '',
'Compare complete token-ID sequences against the first baseline sweep at the same concurrency. Other baseline sweeps are a control for model/scheduler variation.', '',
'| Client concurrency | Exact matches in other baseline sweeps | Exact matches in patched sweeps |', '| --- | --- | --- |']
for batch in (1,4,8,16,32):
    control=[r for r in summary['parity'] if r['batch']==batch and r['label'].startswith('baseline') and not (r['label']=='baseline-a' and r['rep']==0)]
    patched=[r for r in summary['parity'] if r['batch']==batch and r['label'].startswith('patched')]
    lines.append(f"| {batch} | {sum(r['identical_requests'] for r in control)}/{sum(r['total'] for r in control)} | {sum(r['identical_requests'] for r in patched)}/{sum(r['total'] for r in patched)} |")
lines += ['', 'The separate seeded evaluation completed **96/96 requests** across four sessions, producing 6,144 tokens. The first baseline session supplies 24 references; the remaining 72 requests are compared below. Logprob equality covers the complete returned logprob payload.', '',
'| Sampling mode | Other baseline: exact tokens / logprobs | Patched: exact tokens / logprobs |', '| --- | --- | --- |']
for mode in ('greedy','random','filtered'):
    a=[r for r in evals if r['mode']==mode and r['label'].startswith('baseline')]
    b=[r for r in evals if r['mode']==mode and r['label'].startswith('patched')]
    def parity(g): return f"{sum(r['identical_tokens'] for r in g)}/{sum(r['requests'] for r in g)} / {sum(r['identical_logprobs'] for r in g)}/{sum(r['requests'] for r in g)}"
    lines.append(f'| {mode} | {parity(a)} | {parity(b)} |')
lines += ['', f"These finite generation checks do not measure task accuracy or establish bitwise full-model equivalence across independently scheduled sessions. In a separate validation server, both samplers returned identical IDs for all **{live['calls']:,} calls / {live['rows']:,} rows** when given the exact same live model logits. That direct comparison isolates the sampler change; it does not make independently generated model logits identical.", '',
'### Execution-path and startup evidence', '',
f'The untimed baseline profile contains **{baseline_ops} `aten::argmax` calls and {baseline_ops} matching `aten::gather` calls** on `[N, 243]` block scratch tensors. The patched profile contains **{fused_calls} `_gumbel_sample_reduce_kernel` launches** and no argmax/gather calls on that scratch shape. This verifies that the serving workload reaches the changed path; the profiles are not used as timing samples.', '',
'| Session | Reported compilation (s) | Initial profile/warmup (s) | CUDA graph capture (s) |', '| --- | --- | --- |']
for label in ('baseline-a','patched-a','patched-b','baseline-b'):
    log=(ART/f'{label}-server.log').read_text()
    def extract(pattern):
        vals=re.findall(pattern,log)
        return vals[-1] if vals else 'not reported'
    lines.append(f"| {label} | {extract(r'torch.compile took ([0-9.]+) s')} | {extract(r'Initial profiling/warmup run took ([0-9.]+) s')} | {extract(r'Graph capturing finished in ([0-9.]+) secs')} |")
lines += ['', 'Startup and request warmup are excluded from measured cells. Compilation/JIT caches were shared and partly populated while repairing the initial setup, so these observations cannot establish a startup improvement or regression. The benchmark servers were stopped after the final run.', '',
'### Interpretation and limits', '',
f'The patch consistently reduces the isolated final-reduction cost and removes the expected launch and intermediate allocation. Serving median throughput changes range from **{min(changes):+.2f}% to {max(changes):+.2f}%** across the five tested concurrencies. The complete ranges and tail-latency results above must be considered alongside those medians; four repetitions on one H100 are not a general speedup guarantee. These serving runs do not demonstrate a model-level throughput improvement. The demonstrated benefit is the isolated launch/allocation reduction.', '',
'This validation covers one Qwen3.8-27B-FP8 revision, one H100 PCIe, TP=1, one serving configuration, and finite synthetic requests. It does not qualify other GPUs, tensor-parallel sizes, quantizations, the FlashInfer sampling branch, or Model Runner V1. Stochastic draft behavior is covered by sampler/rejection tests and component measurements, not speculative full-model serving. No unrelated campaign optimizations are present in either serving arm.', '',
'AI assistance was used for implementation, review, and validation support.', '']
report=ROOT/'PR_DESCRIPTION.md'
prefix=report.read_text().split('\n## Test Result')[0].rstrip()
report.write_text(prefix+'\n\n'+'\n'.join(lines))
print('REPORT_COMPLETE',report)
